/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.common;

/**
 * Clase de constantes
 *
 * @author Viera Rebolledo Jose B. - jviera.dev@gmail.com
 * @since Junio 2015
 * @version 1.0
 */
public final class Constantes {

    /**
     * Opposite of {@link #FAILS}.
     */
    public static final boolean PASSES = true;
    /**
     * Opposite of {@link #PASSES}.
     */
    public static final boolean FAILS = false;

    /**
     * Opposite of {@link #FAILURE}.
     */
    public static final boolean SUCCESS = true;
    /**
     * Opposite of {@link #SUCCESS}.
     */
    public static final boolean FAILURE = false;

    /**
     * Useful for {@link String} operations, which return an index of
     * <tt>-1</tt> when an item is not found.
     */
    public static final int NOT_FOUND = -1;

    /**
     * System property - <tt>line.separator</tt>
     */
    public static final String NEW_LINE = System.getProperty("line.separator");
    /**
     * System property - <tt>file.separator</tt>
     */
    public static final String FILE_SEPARATOR = System.getProperty("file.separator");
    /**
     * System property - <tt>path.separator</tt>
     */
    public static final String PATH_SEPARATOR = System.getProperty("path.separator");

    public static final String EMPTY_STRING = "";
    public static final String SPACE = " ";
    public static final String TAB = "\t";
    public static final String SINGLE_QUOTE = "'";
    public static final String PERIOD = ".";
    public static final String DOUBLE_QUOTE = "\"";
    public static final String DEFAULT_ENCODING = "UTF-8";
    //Ruta del archivo de propiedades a nivel ClassPath, relatvo al proyecto
    public static final String PROPERTIES_CLASS_PATH = "sysconf/SystemProperties.properties";
    //Ruta del archivo de propiedades a nivel FileSystem, relativo al Sistema Operativo
    public static final String PROPERTIES_FILE_SYSTEM = "/path/";
    //

    /**
     * Formato de fecha para parseo
     */
    public static final String FECHA_FORMATO_DDMMYYYY = "ddMMyyyy";

    /**
     * Indica el tipo de archivo para el parseo del media type pdf
     */
    public static final String TIPO_ARCHIVO_PDF = "application/pdf";
    /**
     * Indica el tipo de archivo para el parseo del media type html
     */
    public static final String TIPO_ARCHIVO_HTML = "application/html";

    /**
     * Id catalo de accion descarga html
     */
    public static final Long ID_ACCION_DSC_HTML = 1L;
    /**
     * Id catalo de accion descarga pdf
     */
    public static final Long ID_ACCION_DSC_PDF = 2L;
    /**
     * Id catalo de accion meses sin intereses
     */
    public static final Long ID_ACCION_MSI = 3L;
    /**
     * Id catalo de accion cargos no reconocidos
     */
    public static final Long ID_ACCION_CNR = 4L;
    /**
     * Id catalo de accion paperless
     */
    public static final Long ID_ACCION_PPL = 5L;
    /**
     * Id catalo de accion tracking
     */
    public static final Long ID_ACCION_TRK = 6L;

    /**
     * id codigo de errores , error
     */
    public static final String CODIGO_ERROR = "00";
    /**
     * id codigo de errores , OK
     */
    public static final String CODIGO_OK = "01";

    /**
     * Ruta del archivo properties para pagina exitosa
     */
    public static final String PAGE_SUCCESS = "page.success";
    
     /**
     * Ruta del archivo properties para pagina fecha
     */
    public static final String PAGE_DATE = "page.date";
    /**
     * Ruta del archivo properties para pagina de error
     */
    public static final String PAGE_ERROR = "page.error";
    /**
     * Ruta del archivo properties para pagina de registro existente
     */
    public static final String PAGE_ALREADY_EXIST = "page.alreadyexist";

    // PRIVATE //
    /**
     * The caller references the constants using <tt>Consts.EMPTY_STRING</tt>,
     * and so on. Thus, the caller should be prevented from constructing objects
     * of this class, by declaring this private constructor.
     */
    private Constantes() {
        //this prevents even the native class from 
        //calling this ctor as well :
        throw new AssertionError();
    }
}
