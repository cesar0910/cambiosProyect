/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

/** clase entity
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
@Entity
@Table(name = "BITACORA")
@SequenceGenerator(name = "SECUENCIA_B", sequenceName = "BITACORA_SEQ", allocationSize = 1)
public class BitacoraEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SECUENCIA_B")
    @Column(name = "ID_BITACORA")
    private Long idBitacora;
    @Size(max = 200)
    @Column(name = "DETALLE_ACCION")
    private String detalleAccion;
    @Column(name = "FECHA")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fecha;
    @Size(max = 200)
    @Column(name = "DIRECCION_IP")
    private String direccionIp;
    @Size(max = 200)
    private String navegador;
    @Size(max = 200)
    private String region;
    @Size(max = 200)
    private String zonaHoraria;
    @Size(max = 200)
    @Column(name = "ID_ERROR")
    private String idError;
    @JoinColumn(name = "ID_ACCION", referencedColumnName = "ID_ACCION")
    @ManyToOne
    private CatalogoAccionEntity idAccion;
    @JoinColumn(name = "NO_CUENTA", referencedColumnName = "NO_CUENTA")
    @ManyToOne
    private TarjetaHabienteEntity noCuenta;

    public BitacoraEntity() {
    }

    public BitacoraEntity(Long idBitacora) {
        this.idBitacora = idBitacora;
    }

    public Long getIdBitacora() {
        return idBitacora;
    }

    public void setIdBitacora(Long idBitacora) {
        this.idBitacora = idBitacora;
    }

    public String getDetalleAccion() {
        return detalleAccion;
    }

    public void setDetalleAccion(String detalleAccion) {
        this.detalleAccion = detalleAccion;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getIdError() {
        return idError;
    }

    public void setIdError(String idError) {
        this.idError = idError;
    }
    
    

    public CatalogoAccionEntity getIdAccion() {
        return idAccion;
    }

    public void setIdAccion(CatalogoAccionEntity idAccion) {
        this.idAccion = idAccion;
    }
    
    public TarjetaHabienteEntity getNoCuenta() {
        return noCuenta;
    }

    public void setNoCuenta(TarjetaHabienteEntity noCuenta) {
        this.noCuenta = noCuenta;
    }

     public String getDireccionIp() {
		return direccionIp;
	}

    public void setDireccionIp(String direccionIp) {
        this.direccionIp = direccionIp;
    }

    public String getNavegador() {
        return navegador;
    }

    public void setNavegador(String navegador) {
        this.navegador = navegador;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }
    public String getZonaHoraria() {
        return zonaHoraria;
    }

    public void setZonaHoraria(String zonaHoraria) {
        this.zonaHoraria = zonaHoraria;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idBitacora != null ? idBitacora.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof BitacoraEntity)) {
            return false;
        }
        BitacoraEntity other = (BitacoraEntity) object;
        if ((this.idBitacora == null && other.idBitacora != null) || (this.idBitacora != null && !this.idBitacora.equals(other.idBitacora))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "mx.com.tsys.ws.entity.BitacoraEntity[ idBitacora=" + idBitacora + " ]";
    }
    
}
