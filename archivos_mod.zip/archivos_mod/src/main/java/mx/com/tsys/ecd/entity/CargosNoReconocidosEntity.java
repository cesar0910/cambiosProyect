/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * clase entity
 *
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
@Entity
@Table(name = "CARGOS_NO_RECONOCIDOS")
public class CargosNoReconocidosEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "ID_TRANSACCION")
    private String idTransaccion;
    @Size(max = 200)
    @Column(name = "DETALLE")
    private String detalle;
    @Column(name = "FECHA")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fecha;
    @Size(max = 30)
    @Column(name = "PLANCNR")
    private String plancnr;
    @JoinColumn(name = "ID_ESTADO_CUENTA", referencedColumnName = "ID_ESTADO_CUENTA")
    @ManyToOne
    private EstadoCuentaEntity idEstadoCuenta;

    public CargosNoReconocidosEntity() {
    }

    public CargosNoReconocidosEntity(String idTransaccion) {
        this.idTransaccion = idTransaccion;
    }

    public String getIdTransaccion() {
        return idTransaccion;
    }

    public void setIdTransaccion(String idTransaccion) {
        this.idTransaccion = idTransaccion;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getPlancnr() {
        return plancnr;
    }

    public void setPlancnr(String plancnr) {
        this.plancnr = plancnr;
    }

    public EstadoCuentaEntity getIdEstadoCuenta() {
        return idEstadoCuenta;
    }

    public void setIdEstadoCuenta(EstadoCuentaEntity idEstadoCuenta) {
        this.idEstadoCuenta = idEstadoCuenta;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idTransaccion != null ? idTransaccion.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CargosNoReconocidosEntity)) {
            return false;
        }
        CargosNoReconocidosEntity other = (CargosNoReconocidosEntity) object;
        if ((this.idTransaccion == null && other.idTransaccion != null) || (this.idTransaccion != null && !this.idTransaccion.equals(other.idTransaccion))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "mx.com.tsys.ws.entity.CargosNoReconocidosEntity[ idTransaccion=" + idTransaccion + " ]";
    }

}
