/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * clase entity
 *
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
@Entity
@Table(name = "CODIGO_ERRORES")
public class CodigoErroresEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "ID_ERROR")
    private String idError;
    @Size(max = 100)
    @Column(name = "DESCRIPCION")
    private String descripcion;

    public CodigoErroresEntity() {
    }

    public CodigoErroresEntity(String idError) {
        this.idError = idError;
    }

    public String getIdError() {
        return idError;
    }

    public void setIdError(String idError) {
        this.idError = idError;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idError != null ? idError.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CodigoErroresEntity)) {
            return false;
        }
        CodigoErroresEntity other = (CodigoErroresEntity) object;
        if ((this.idError == null && other.idError != null) || (this.idError != null && !this.idError.equals(other.idError))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "mx.com.tsys.ws.entity.CodigoErroresEntity[ idError=" + idError + " ]";
    }
    
}
