/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * clase entity
 *
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
@Entity
@Table(name = "PAPERLESS")
@SequenceGenerator(name = "SECUENCIA_P", sequenceName="Secuencia_paperless", allocationSize=1)
public class PaperlessEntity implements Serializable {
     private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Id
  @Basic(optional = false)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SECUENCIA_P")
  @Column(name = "ID_PAPERLESS", nullable = false)
  private Long idPaperless;
    @Column(name = "APLICA")
    private String aplica;
    @Column(name = "FECHA")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fecha;
    @JoinColumn(name = "NO_CUENTA", referencedColumnName = "NO_CUENTA")
    @ManyToOne
    private TarjetaHabienteEntity noCuenta;

    public PaperlessEntity() {
    }

    public PaperlessEntity(Long idPaperless) {
        this.idPaperless = idPaperless;
    }

    public Long getIdPaperless() {
        return idPaperless;
    }

    public void setIdPaperless(Long idPaperless) {
        this.idPaperless = idPaperless;
    }

    public String getAplica() {
        return aplica;
    }

    public void setAplica(String aplica) {
        this.aplica = aplica;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public TarjetaHabienteEntity getNoCuenta() {
        return noCuenta;
    }

    public void setNoCuenta(TarjetaHabienteEntity noCuenta) {
        this.noCuenta = noCuenta;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPaperless != null ? idPaperless.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PaperlessEntity)) {
            return false;
        }
        PaperlessEntity other = (PaperlessEntity) object;
        if ((this.idPaperless == null && other.idPaperless != null) || (this.idPaperless != null && !this.idPaperless.equals(other.idPaperless))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "mx.com.tsys.ws.entity.PaperlessEntity[ idPaperless=" + idPaperless + " ]";
    }
    
}
