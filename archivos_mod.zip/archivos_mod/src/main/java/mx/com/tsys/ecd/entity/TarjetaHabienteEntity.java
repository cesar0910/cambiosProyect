/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * clase entity
 *
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
@Entity
@Table(name = "TARJETA_HABIENTE")
public class TarjetaHabienteEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "NO_CUENTA")
    private String noCuenta;
    @Size(max = 30)
    @Column(name = "NOMBRE")
    private String nombre;
    @Size(max = 30)
    @Column(name = "AP_PATERNO")
    private String apPaterno;
    @Size(max = 30)
    @Column(name = "AP_MATERNO")
    private String apMaterno;
    @Size(max = 100)
    @Column(name = "DIR_CALLE")
    private String dirCalle;
    @Size(max = 100)
    @Column(name = "DIR_COLONIA")
    private String dirColonia;
    @Size(max = 60)
    @Column(name = "DIR_CIUDAD")
    private String dirCiudad;
    @Size(max = 60)
    @Column(name = "DIR_ESTADO")
    private String dirEstado;
    @Size(max = 5)
    @Column(name = "DIR_CP")
    private String dirCp;
    @Size(max = 100)
    @Column(name = "PASSWORD")
    private String password;
    @OneToMany(mappedBy = "noCuenta")
    private List<BitacoraEntity> bitacoraEntityList;
    @OneToMany(mappedBy = "noCuenta")
    private List<PaperlessEntity> paperlessEntityList;
    @OneToMany(mappedBy = "noCuenta")
    private List<EstadoCuentaEntity> estadoCuentaEntityList;
    @JoinColumn(name = "RFC_BANCO", referencedColumnName = "RFC")
    @ManyToOne
    private BancoEntity rfcBanco;

    public TarjetaHabienteEntity() {
    }

    public TarjetaHabienteEntity(String noCuenta) {
        this.noCuenta = noCuenta;
    }

    public String getNoCuenta() {
        return noCuenta;
    }

    public void setNoCuenta(String noCuenta) {
        this.noCuenta = noCuenta;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApPaterno() {
        return apPaterno;
    }

    public void setApPaterno(String apPaterno) {
        this.apPaterno = apPaterno;
    }

    public String getApMaterno() {
        return apMaterno;
    }

    public void setApMaterno(String apMaterno) {
        this.apMaterno = apMaterno;
    }

    public String getDirCalle() {
        return dirCalle;
    }

    public void setDirCalle(String dirCalle) {
        this.dirCalle = dirCalle;
    }

    public String getDirColonia() {
        return dirColonia;
    }

    public void setDirColonia(String dirColonia) {
        this.dirColonia = dirColonia;
    }

    public String getDirCiudad() {
        return dirCiudad;
    }

    public void setDirCiudad(String dirCiudad) {
        this.dirCiudad = dirCiudad;
    }

    public String getDirEstado() {
        return dirEstado;
    }

    public void setDirEstado(String dirEstado) {
        this.dirEstado = dirEstado;
    }

    public String getDirCp() {
        return dirCp;
    }

    public void setDirCp(String dirCp) {
        this.dirCp = dirCp;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<BitacoraEntity> getBitacoraEntityList() {
        return bitacoraEntityList;
    }

    public void setBitacoraEntityList(List<BitacoraEntity> bitacoraEntityList) {
        this.bitacoraEntityList = bitacoraEntityList;
    }

    public List<PaperlessEntity> getPaperlessEntityList() {
        return paperlessEntityList;
    }

    public void setPaperlessEntityList(List<PaperlessEntity> paperlessEntityList) {
        this.paperlessEntityList = paperlessEntityList;
    }

    public List<EstadoCuentaEntity> getEstadoCuentaEntityList() {
        return estadoCuentaEntityList;
    }

    public void setEstadoCuentaEntityList(List<EstadoCuentaEntity> estadoCuentaEntityList) {
        this.estadoCuentaEntityList = estadoCuentaEntityList;
    }

    public BancoEntity getRfcBanco() {
        return rfcBanco;
    }

    public void setRfcBanco(BancoEntity rfcBanco) {
        this.rfcBanco = rfcBanco;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (noCuenta != null ? noCuenta.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TarjetaHabienteEntity)) {
            return false;
        }
        TarjetaHabienteEntity other = (TarjetaHabienteEntity) object;
        if ((this.noCuenta == null && other.noCuenta != null) || (this.noCuenta != null && !this.noCuenta.equals(other.noCuenta))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "mx.com.tsys.ws.entity.TarjetaHabienteEntity[ noCuenta=" + noCuenta + " ]";
    }
    
}
