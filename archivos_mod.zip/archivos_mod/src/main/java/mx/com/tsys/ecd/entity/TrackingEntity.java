/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package mx.com.tsys.ecd.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

/**
 * clase entity
 *
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
@Entity
@Table(name = "TRACKING")
@SequenceGenerator(name = "SECUENCIA_T", sequenceName="Secuencia_tracking", allocationSize=1)
public class TrackingEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SECUENCIA_T")
    @Column(name = "ID_TRACKING", nullable = false)
    private Long idTracking;
    @Column(name = "DETALLE")
    private String detalle;
    @Column(name = "FECHA")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fecha;
    @Size(max = 150)
    @Column(name = "URL")
    private String url;
    @JoinColumn(name = "ID_ESTADO_CUENTA", referencedColumnName = "ID_ESTADO_CUENTA")
    @ManyToOne
    private EstadoCuentaEntity idEstadoCuenta;

    public TrackingEntity() {
    }

    public TrackingEntity(Long idTracking) {
        this.idTracking = idTracking;
    }

    public Long getIdTracking() {
        return idTracking;
    }

    public void setIdTracking(Long idTracking) {
        this.idTracking = idTracking;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public EstadoCuentaEntity getIdEstadoCuenta() {
        return idEstadoCuenta;
    }

    public void setIdEstadoCuenta(EstadoCuentaEntity idEstadoCuenta) {
        this.idEstadoCuenta = idEstadoCuenta;
    }
    
    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idTracking != null ? idTracking.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TrackingEntity)) {
            return false;
        }
        TrackingEntity other = (TrackingEntity) object;
        if ((this.idTracking == null && other.idTracking != null) || (this.idTracking != null && !this.idTracking.equals(other.idTracking))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "mx.com.tsys.ws.entity.Tracking[ idTracking=" + idTracking + " ]";
    }

    
    
}
