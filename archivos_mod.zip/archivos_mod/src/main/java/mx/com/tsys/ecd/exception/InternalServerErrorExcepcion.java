/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Clase que cacha y trata las excepciones generadas por un error interno en el
 * servicio.
 * @author Viera Rebolledo Jose B.  -   jviera.dev@gmail.com
 * @since Julio 2015
 * @version 1.0
 */

@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR, reason = "Se genero un error interno en el servicio.")
public class InternalServerErrorExcepcion extends RuntimeException {

    public InternalServerErrorExcepcion() {
    }   
    
    public InternalServerErrorExcepcion(String message) {
        super(message);
    }

    public InternalServerErrorExcepcion(String message, Throwable cause) {
        super(message, cause);
    }

    public InternalServerErrorExcepcion(Throwable cause) {
        super(cause);
    }    
    
}
