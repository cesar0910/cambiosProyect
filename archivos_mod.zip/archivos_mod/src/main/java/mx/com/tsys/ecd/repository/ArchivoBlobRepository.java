/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package mx.com.tsys.ecd.repository;
import org.springframework.data.jpa.repository.Query;
import mx.com.tsys.ecd.entity.ArchivoBlobEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author TSYS01
 */
public interface ArchivoBlobRepository extends CrudRepository<ArchivoBlobEntity, Integer>{
     /**
    * realiza una busqueda en estado de cuenta filtrando por 
    * No de cuenta 
    * @param idArchivoBlob
    * @param idTipo
    * @return 
    */
    
    
    @Query("select e from ArchivoBlobEntity e where e.idArchivoBlob = :idArchivoBlob and e.idTipo = :idTipo")
   ArchivoBlobEntity findByIdArchivoBlobAndIdTipo(@Param("idArchivoBlob") Integer idArchivoBlob, @Param("idTipo") String idTipo);
   
}

