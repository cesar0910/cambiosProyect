/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.repository;

import java.util.Date;
import mx.com.tsys.ecd.entity.EstadoCuentaEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

/**
 * repositorio
 *
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
public interface EstadoCuentaRepository extends CrudRepository<EstadoCuentaEntity, String>{
    /**
     * realiza una busqueda en estado de cuenta filtrando por 
     * No de cuenta y fecha de corte
     * @param noCuenta
     * @param fechacorte
     * @return 
     */
   @Query("select e from EstadoCuentaEntity e where e.noCuenta = :noCuenta and e.fechaCorte = :fechaCorte")
   EstadoCuentaEntity findByNoCuentaAndFechaCorte(@Param("noCuenta") String noCuenta, @Param("fechaCorte") Date fechacorte); 
   
   /**
    * realiza una busqueda en estado de cuenta filtrando por 
    * No de cuenta 
    * @param noCuenta
    * @return 
    */
    @Query("select e from EstadoCuentaEntity e where e.idEstadoCuenta = :noCuenta")
   EstadoCuentaEntity findByNoCuenta(@Param("noCuenta") String noCuenta); 
}
