/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.service.rest;

import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import mx.com.tsys.ecd.common.CommonUtils;
import mx.com.tsys.ecd.common.Constantes;
import mx.com.tsys.ecd.common.StackTraceUtil;
import mx.com.tsys.ecd.entity.ArchivoBlobEntity;
import mx.com.tsys.ecd.entity.CatalogoAccionEntity;
import mx.com.tsys.ecd.entity.EstadoCuentaEntity;
import mx.com.tsys.ecd.entity.TarjetaHabienteEntity;
import mx.com.tsys.ecd.exception.InternalServerErrorExcepcion;
import mx.com.tsys.ecd.exception.InvalidInputDataException;
import mx.com.tsys.ecd.exception.UnauthorizedException;
import mx.com.tsys.ecd.repository.ArchivoBlobRepository;
import mx.com.tsys.ecd.repository.BitacoraRepository;
import mx.com.tsys.ecd.repository.CatalogoAccionRepository;
import mx.com.tsys.ecd.repository.EstadoCuentaRepository;
import mx.com.tsys.ecd.repository.TarjetaHabienteRepository;
import mx.com.tsys.ecd.util.DateUtil;
import mx.com.tsys.ecd.util.FileFromByteUtil;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Clase que expone los servicios Rest
 *
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
@RestController
@RequestMapping("/rest")
public class DescargaEstadoCuentaHtmlRest {

    //Lleva la bitacora de logs segun la configuracion del archivo log4j2.xml
    private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(DescargaEstadoCuentaHtmlRest.class.getName());

    @Autowired
    private EstadoCuentaRepository estadoCuentaRepository;

    @Autowired
    private TarjetaHabienteRepository tarjetaHabienteRepository;

    @Autowired
    private CatalogoAccionRepository catalogoAccionRepository;

    @Autowired
    private BitacoraRepository bitacoraRepository;

    @Autowired
    private ArchivoBlobRepository archivoBlobRepository;

    /**
     * Servicio descarga estado de cuenta en Html a partir de numeor de cuenta y
     * fecha corte
     *
     * @param noCuenta
     * @param fechaCorte
     * @return archivo Html
     */
    @RequestMapping(value = "/dsc/dnm/{noCuenta}/{fechaCorte}", method = RequestMethod.GET)
    @ResponseBody
   public ResponseEntity<byte[]> descargaEstadoCuentaHtml(@PathVariable("noCuenta") String noCuenta, @PathVariable("fechaCorte") String fechaCorte, HttpServletRequest request) {
        ResponseEntity<byte[]> response = null;
        String mensaje = "OK";
        try {
            log.info("Solicitud descarga de estado de cuenta html...");
            if (CommonUtils.isEmpty(noCuenta) || CommonUtils.isEmpty(fechaCorte)) {
                log.info("no Cuenta/fecha corte is null.");
                mensaje = "no Cuenta/fecha corte is null.";
                throw new InvalidInputDataException("no Cuenta/fecha corte is null.");
            } else {

                Date fecha = DateUtil.parseDate(fechaCorte, Constantes.FECHA_FORMATO_DDMMYYYY);
                EstadoCuentaEntity estadoCuentaEntity = estadoCuentaRepository.findByNoCuentaAndFechaCorte(noCuenta, fecha);
                tarjetaHabienteRepository.findOne(noCuenta);

                if (estadoCuentaEntity != null) {
                    
                   //byte[] contents = estadoCuentaEntity.getEcd();
                    //se crea el archivo 
                    //response = FileFromByteUtil.creaArchivo(contents, Constantes.TIPO_ARCHIVO_HTML, "estadoCuenta.html");

                    mensaje = "Se descargo exitosamente el Html";

                try {
                        ArchivoBlobEntity archivoBlobEntity = archivoBlobRepository.findOne(1);
                        //ArchivoBlobEntity archivoBlobEntity2 = archivoBlobRepository.findByIdTipo(1, "1");
                        if (archivoBlobEntity != null) {
                            byte [] contents = archivoBlobEntity.getArchivoBlob();
                           
                         //se crea el archivo 
                            response = FileFromByteUtil.creaArchivo(contents, Constantes.TIPO_ARCHIVO_HTML, "estadoCuenta.html");
                        }
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                        System.out.println(e.getCause());
                    }

                      
                    
                    
                } else {
                    mensaje = "no se encontro estado de cuenta";
                }
            }

            return response;

        } catch (InvalidInputDataException e) {
            log.error(StackTraceUtil.getStackTrace(e));
            throw new InvalidInputDataException(e.getMessage());
        } catch (UnauthorizedException e) {
            log.error(StackTraceUtil.getStackTrace(e));
            throw new UnauthorizedException(e.getMessage());
        } catch (Exception e) {
            log.error(StackTraceUtil.getStackTrace(e));
            mensaje = "Se genero un error interno.";
            throw new InternalServerErrorExcepcion("Se genero un error interno.");
        } finally {
            TarjetaHabienteEntity tarjetaHabienteEntity = (CommonUtils.isEmpty(noCuenta))
                    ? null : tarjetaHabienteRepository.findOne(noCuenta);
            CatalogoAccionEntity catalogoAccionEntity = catalogoAccionRepository.findOne(Constantes.ID_ACCION_DSC_HTML);
            bitacoraRepository.guardaBitacora(tarjetaHabienteEntity, catalogoAccionEntity, Constantes.CODIGO_ERROR, mensaje, request);
        }
    }

}
