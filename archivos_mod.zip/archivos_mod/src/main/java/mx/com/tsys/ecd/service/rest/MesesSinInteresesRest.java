/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.service.rest;

import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import mx.com.tsys.ecd.common.CommonUtils;
import mx.com.tsys.ecd.common.Constantes;
import mx.com.tsys.ecd.common.StackTraceUtil;
import mx.com.tsys.ecd.common.SystemProperties;
import mx.com.tsys.ecd.entity.CatalogoAccionEntity;
import mx.com.tsys.ecd.entity.EstadoCuentaEntity;
import mx.com.tsys.ecd.entity.MesesSinInteresesEntity;
import mx.com.tsys.ecd.entity.TarjetaHabienteEntity;
import mx.com.tsys.ecd.exception.InternalServerErrorExcepcion;
import mx.com.tsys.ecd.exception.InvalidInputDataException;
import mx.com.tsys.ecd.exception.UnauthorizedException;
import mx.com.tsys.ecd.repository.BitacoraRepository;
import mx.com.tsys.ecd.repository.CatalogoAccionRepository;
import mx.com.tsys.ecd.repository.EstadoCuentaRepository;
import mx.com.tsys.ecd.repository.MesesSinInteresesRepository;
import mx.com.tsys.ecd.repository.TarjetaHabienteRepository;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

/**
 * Clase que expone los servicios Rest
 *
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
@RestController
@RequestMapping("/rest")
public class MesesSinInteresesRest {

    //Lleva la bitacora de logs segun la configuracion del archivo log4j2.xml
    private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(MesesSinInteresesRest.class.getName());

    @Autowired
    private MesesSinInteresesRepository mesesSinInteresesRepository;

    @Autowired
    private EstadoCuentaRepository estadoCuentaRepository;

    @Autowired
    private TarjetaHabienteRepository tarjetaHabienteRepository;

    @Autowired
    private CatalogoAccionRepository catalogoAccionRepository;

    @Autowired
    private BitacoraRepository bitacoraRepository;

    /**
     * servicio que almacena meses sin intereses
     * @param noCuenta
     * @param idTransaccion
     * @param plan
     * @return 
     */
    @RequestMapping(value = "/msi/{idTransaccion}/{noCuenta}/{plan}", method = RequestMethod.GET)
    @ResponseBody
    public RedirectView mesesSinIntereses(@PathVariable("idTransaccion") String idTransaccion, @PathVariable("noCuenta") String noCuenta, @PathVariable("plan") String plan, HttpServletRequest request) {
        boolean success = false;
        String mensaje = "OK";
        String noCuentaTmp="";
        String redirect = request.getSession().getServletContext()
				.getInitParameter("test");
        try {
            log.info("Solicitud meses sin intereses...");
            if (CommonUtils.isEmpty(noCuenta) || CommonUtils.isEmpty(idTransaccion) || CommonUtils.isEmpty(plan)) {
                log.info("no Cuenta/id transaccion / plan is null.");
                mensaje = "no Cuenta/id transaccion / plan is null.";
                throw new InvalidInputDataException("no Cuenta/id transaccion / plan is null.");
            } else {

                EstadoCuentaEntity estadoCuentaEntity = estadoCuentaRepository.findByNoCuenta(noCuenta);
                MesesSinInteresesEntity mesesSinInteresesEntity = mesesSinInteresesRepository.findOne(idTransaccion);

                if (estadoCuentaEntity != null && mesesSinInteresesEntity == null) {
                    //guarda en msi
                    noCuentaTmp=estadoCuentaEntity.getNoCuenta().getNoCuenta();
                    mesesSinInteresesEntity = new MesesSinInteresesEntity();
                    mesesSinInteresesEntity.setIdTransaccion(idTransaccion);
                    mesesSinInteresesEntity.setPlanmsi(plan);
                    mesesSinInteresesEntity.setFecha(new Date());
                    mesesSinInteresesEntity.setIdEstadoCuenta(estadoCuentaEntity);
                    mesesSinInteresesRepository.save(mesesSinInteresesEntity);
                    success = true;
                }
            }

            return success ? new RedirectView(SystemProperties.getPropertyClassPath(Constantes.PAGE_SUCCESS), true)
                    : new RedirectView(SystemProperties.getPropertyClassPath(Constantes.PAGE_ALREADY_EXIST), true);
        } catch (InvalidInputDataException e) {
            log.error(StackTraceUtil.getStackTrace(e));
            throw new InvalidInputDataException(e.getMessage());
        } catch (UnauthorizedException e) {
            log.error(StackTraceUtil.getStackTrace(e));
            throw new UnauthorizedException(e.getMessage());
        } catch (Exception e) {
            log.error(StackTraceUtil.getStackTrace(e));
            mensaje = "Se genero un error interno.";
            throw new InternalServerErrorExcepcion("Se genero un error interno.");

        } finally {
            TarjetaHabienteEntity tarjetaHabienteEntity = (CommonUtils.isEmpty(noCuentaTmp))
                    ? null : tarjetaHabienteRepository.findOne(noCuentaTmp);
            CatalogoAccionEntity catalogoAccionEntity = catalogoAccionRepository.findOne(Constantes.ID_ACCION_MSI);
            bitacoraRepository.guardaBitacora(tarjetaHabienteEntity, catalogoAccionEntity, Constantes.CODIGO_ERROR, mensaje, request);
        
        }
    }
}               
                                                                      