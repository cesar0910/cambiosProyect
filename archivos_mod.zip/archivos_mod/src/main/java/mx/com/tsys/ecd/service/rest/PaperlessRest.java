/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.service.rest;

import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import mx.com.tsys.ecd.common.CommonUtils;
import mx.com.tsys.ecd.common.Constantes;
import mx.com.tsys.ecd.common.StackTraceUtil;
import mx.com.tsys.ecd.common.SystemProperties;
import mx.com.tsys.ecd.entity.CatalogoAccionEntity;
import mx.com.tsys.ecd.entity.TarjetaHabienteEntity;
import mx.com.tsys.ecd.entity.PaperlessEntity;
import mx.com.tsys.ecd.exception.InternalServerErrorExcepcion;
import mx.com.tsys.ecd.exception.InvalidInputDataException;
import mx.com.tsys.ecd.exception.UnauthorizedException;
import mx.com.tsys.ecd.repository.BitacoraRepository;
import mx.com.tsys.ecd.repository.PaperlessRepository;
import mx.com.tsys.ecd.repository.TarjetaHabienteRepository;
import mx.com.tsys.ecd.repository.CatalogoAccionRepository;

import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

/**
 * Clase que expone los servicios Rest
 *
 * @since septiembre 2015
 * @version 1.0
 * @author cesar Ruiz
 */
@RestController
@RequestMapping("/rest")
public class PaperlessRest {

    //Lleva la bitacora de logs segun la configuracion del archivo log4j2.xml
    private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(PaperlessRest.class.getName());

    @Autowired
    private PaperlessRepository paperlessRepository;

    @Autowired
    private TarjetaHabienteRepository tarjetaHabienteRepository;

    @Autowired
    private BitacoraRepository bitacoraRepository;

    @Autowired
    private CatalogoAccionRepository catalogoAccionRepository;

    /**
     * servicio que gestiona la entrega fisica o digital 
     * del estado de cuenta 
     * @param noCuenta
     * @param aplica
     * @return 
     */
    @RequestMapping(value = "/ppl/{noCuenta}/{aplica}", method = RequestMethod.GET)
    @ResponseBody
    public RedirectView paperless(@PathVariable("noCuenta") String noCuenta, @PathVariable("aplica") String aplica, Character Aplica, HttpServletRequest request) {
        boolean success = false;
        String mensaje = "OK";
        try {
            log.info("Solicitud paperless...");
            if (CommonUtils.isEmpty(noCuenta)) {
                log.info("no Cuenta/ aplica is null.");
             
                throw new InvalidInputDataException("no Cuenta/ aplica is null.");
            } else {
                TarjetaHabienteEntity tarjetaHabienteEntity = tarjetaHabienteRepository.findOne(noCuenta);

                if (tarjetaHabienteEntity != null) {
                    //guarda en ppl
                    PaperlessEntity paperlessEntity = new PaperlessEntity();
                    paperlessEntity.setAplica(aplica);
                    paperlessEntity.setFecha(new Date());
                    paperlessEntity.setNoCuenta(tarjetaHabienteEntity);
                    
                    paperlessRepository.save(paperlessEntity);
                     success = true;
                }
               

            }

           
            return success ? new RedirectView(SystemProperties.getPropertyClassPath(Constantes.PAGE_SUCCESS), true)
                    : new RedirectView(SystemProperties.getPropertyClassPath(Constantes.PAGE_ALREADY_EXIST), true);
        } catch (InvalidInputDataException e) {
            log.error(StackTraceUtil.getStackTrace(e));
            throw new InvalidInputDataException(e.getMessage());
        } catch (UnauthorizedException e) {
            log.error(StackTraceUtil.getStackTrace(e));
            throw new UnauthorizedException(e.getMessage());
        } catch (Exception e) {
            log.error(StackTraceUtil.getStackTrace(e));
            mensaje = "Se genero un error interno.";
            throw new InternalServerErrorExcepcion("Se genero un error interno.");

        }finally {
            TarjetaHabienteEntity tarjetaHabienteEntity = (CommonUtils.isEmpty(noCuenta))
                    ? null : tarjetaHabienteRepository.findOne(noCuenta);
            CatalogoAccionEntity catalogoAccionEntity = catalogoAccionRepository.findOne(Constantes.ID_ACCION_PPL);
            bitacoraRepository.guardaBitacora(tarjetaHabienteEntity, catalogoAccionEntity, Constantes.CODIGO_ERROR, mensaje, request);
        }
    }
}
