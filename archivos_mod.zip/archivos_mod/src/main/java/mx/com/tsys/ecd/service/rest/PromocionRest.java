/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.service.rest;

import javax.servlet.http.HttpServletRequest;
import mx.com.tsys.ecd.common.CommonUtils;
import mx.com.tsys.ecd.common.Constantes;
import mx.com.tsys.ecd.common.StackTraceUtil;
import mx.com.tsys.ecd.common.SystemProperties;
import mx.com.tsys.ecd.entity.PromocionEntity;
import mx.com.tsys.ecd.exception.InvalidInputDataException;
import mx.com.tsys.ecd.exception.UnauthorizedException;
import mx.com.tsys.ecd.repository.PromocionRepository;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

/**
 * Clase que expone los servicios Rest
 *
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
@RestController
@RequestMapping("/rest")
public class PromocionRest {

    //Lleva la bitacora de logs segun la configuracion del archivo log4j2.xml
    private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(PromocionRest.class.getName());

    @Autowired
    private PromocionRepository promocionRepository;

    /**
     * servicio que almacena meses sin intereses
     *
     * @param idpromo
     * @return
     */
    @RequestMapping(value = "/prom/{idpromo}", method = RequestMethod.GET)
    @ResponseBody
    public RedirectView promocion(@PathVariable("idpromo") String idpromo, HttpServletRequest request) {
        boolean success = false;
        String mensaje = "OK";
        java.util.Date fechaActual = new java.util.Date();
        String redirect = request.getSession().getServletContext()
                .getInitParameter("fecha");
        try {
            log.info("Solicitud promocion...");
            if (CommonUtils.isEmpty(idpromo)) {
                log.info("idpromo is null.");
                mensaje = "idpromo is null.";
                throw new InvalidInputDataException("idpromo is null.");
            } else {

                PromocionEntity promocionEntity = promocionRepository.findOne(idpromo);

                if (promocionEntity != null) {
                    //guarda en promo

                    if (fechaActual.after(promocionEntity.getCaducidad())) {
                       
                        success = true;
                    } else {
                        return new RedirectView(promocionEntity.getUrl());
                    }
                }
            }
            return success ? new RedirectView(SystemProperties.getPropertyClassPath(Constantes.PAGE_DATE), true)
                    : new RedirectView(SystemProperties.getPropertyClassPath(Constantes.PAGE_ALREADY_EXIST), true);
        } catch (InvalidInputDataException e) {
            log.error(StackTraceUtil.getStackTrace(e));
            throw new InvalidInputDataException(e.getMessage());
        } catch (UnauthorizedException e) {
            log.error(StackTraceUtil.getStackTrace(e));
            throw new UnauthorizedException(e.getMessage());
        }
    }
}


