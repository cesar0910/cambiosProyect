/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.util;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

/**Esta clase contie metodos estaticos para manipulacion 
 * de byte 
 * @since 04/09/2015
 * @version 1.0
 * @author Said Guerrero
 */
public class FileFromByteUtil {

    /**
     * Contruye un archivo a partir de los datos en 
     * binario, el tipo de archivo y el nombre que tendra 
     * @param contents 
     * @param tipoArchivo 
     * @param nombreArchivo
     * @return 
     */
    public static ResponseEntity<byte[]> creaArchivo(byte[] contents, String tipoArchivo, String nombreArchivo) {
        ResponseEntity<byte[]> response = null;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType(tipoArchivo));
        String filename = nombreArchivo;
        headers.setContentDispositionFormData(filename, filename);
        headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
        return response = new ResponseEntity<byte[]>(contents, headers, HttpStatus.OK);
    }

}
